var config = {
    map: {
        '*': {
            'example-modal': 'Dharmendra_Dharm/js/example-modal'
        }
    }
};