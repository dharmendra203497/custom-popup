<?php
namespace Dharmendra\Dharm\Block;
class Example extends \Magento\Framework\View\Element\Template
{
    public function getContent() 
    {
        return 'Dummy content';
    }
}